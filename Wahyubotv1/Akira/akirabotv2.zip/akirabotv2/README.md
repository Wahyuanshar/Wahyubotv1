![logo](https://user-images.githubusercontent.com/79284980/110831365-bebe1680-82cc-11eb-9d82-d6fe4d131222.jpg)
------------------------------------
Versi Indonesia

Cara Install Script Ini

1. buka termux
2. apt-get install bash
3. apt-get install git
3. git clone https://github.com/dappauhuy/dapbot-cuy
4. cd dapbot-cuy
5. bash install.sh
6. node index.js

Scan Kode Qr Di WhatsApp Web
Selesai:)
Selamat Bermain Bot:)

Jika error silahkan download node_modules terlebih dahulu link ada dibawah

Cara pasang node_modules

1. Extract file node_modules
2. Buka termux
3. termux-setup-storage
4. cd dapbot-cuy
5. cp -r /sdcard/download/node_modules $HOME
6. node index.js

Selesai:)

------------------------------------
English Version

How To Install This Script

1. open termux
2. apt-get install bash
3. apt-get install git
3. git clone https://github.com/dappauhuy/dapbot-cuy
4. cd dapbot-cuy
5. bash install.sh
6. node index.js

Scan Qr Code On WhatsApp Web
Done:)
Happy Playing Bot:)

If an error, please download node_modules first, the link is below

How to install node_modules

1. Extract the node_modules file
2. Open termux
3. termux-setup-storage
4. cd dapbot-cuy
5. cp -r / sdcard / download / node_modules $ HOME
6. node index.js

Done:)


Link Node_Modules : https://www.mediafire.com/download/0d4clcwovbwhpjk
